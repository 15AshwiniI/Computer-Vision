import numpy as np

""" Note that this file only contains code to calculate the homography
	matrix given [N, 2] correspondences. Handling of homogenous coords is
	done in warpImage.
"""

def computeH(t1, t2):
	# t1, t2 are [N, 2] matrices
	# returns 3 x 3 homography matrix

	# q appended with 1 is [3, 1]
	# p appended with 1 is [3, 1]

	# [1, 1] -> [255, 255]
	num_points = t1.shape[0]

	temp = []
	for point_idx in range(num_points):
		x, y = t1[point_idx]
		n, m = t2[point_idx]
		temp.append([x, y, 1, 0, 0, 0, -x*n, -y*n, -n])
		temp.append([0, 0, 0, x, y, 1, -x*m, -y*m, -m])
	temp = np.array(temp)
	a1, b1, c1 = np.linalg.svd(temp)
	L = c1[-1, :] / c1[-1, -1]
	return L.reshape(3, 3)