
computeH.py 
	has the function that creates the homography matrix
warpImage.py 
	Is the file containing main logic. Can be run through command line using:
		If you want to manually select the corresponding points:
			python warpImage.py “image1”.jpg “image2”.jpg 
		If you have corresponding points you want to include:
			python warpImage.py “image1”.jpg “image2”.jpg “corr_point1”.npy “corr_point2”.npy
points.npy  
	contains the variables that contain points1 and points2 for pair 2 in question 4. 


For Pair 1, the input images are called crop1.jpg and crop2.jpg and the corresponding points are called cc1.npy and cc2.npy
For Pair 2, the input images are called wdc1.jpg and wdc2.jpg, the corresponding points are saved in a dictionary in a file called points.py. If you want to run main.py with the corresponding points, you can do that by sending in the files points1.npy and points2.npy as the corresponding point input in the command line. These files contain the same information stored in the dictionary, just separated based on the images they came from for ease of use.
For Pair 3, the images are called pic1.jpg and pic2.jpg. 

WARNINGS: 

If you choose points instead of providing the files, then a points.npy, points1.npy, and points2.npy files will be generated overwriting existing ones. I have submitted the points I used to create the image, if you select points they will be lost and you will have to redownload my submission to verify my image. 

Also, when selecting corresponding points make sure to select the same number of points on each image other. Program will not function as intended otherwise.

