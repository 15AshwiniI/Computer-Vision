import sys
import numpy as np
import matplotlib.pyplot as plt
from computeH import computeH
pos1 = []
pos2 = []

def onclick1(event):
	pos1.append([event.xdata,event.ydata])
	print('%s click: button=%d, x=%d, y=%d, xdata=%f, ydata=%f' %
		  ('double' if event.dblclick else 'single', event.button,
		   event.x, event.y, event.xdata, event.ydata))

def onclick2(event):
	pos2.append([event.xdata,event.ydata])
	print('%s click: button=%d, x=%d, y=%d, xdata=%f, ydata=%f' %
		  ('double' if event.dblclick else 'single', event.button,
		   event.x, event.y, event.xdata, event.ydata))


""" (w, h) is the standard for this function for inputs and return
"""
def warp(H, w, h, d):
	w_new, h_new, z = np.matmul(H, [w, h, 1])
	return w_new/z, h_new/z

def image_nonzero_pixel(im, h, w, offset_y=0, offset_x=0):
	max_h, max_w, _ = im.shape
	if (h+offset_y) < max_h and (w+offset_x) < max_w and (h+offset_y) > 0 and (w+offset_x) > 0:
		return im[h+offset_y, w+offset_x].tolist() != [0, 0, 0]

""" Takes two images, returns and image with dimensions (h_max of two images, w_max of two images)
	Image 2 will overwrite image 1
"""
def overlayImages(im1, im2, offset_y, offset_x):
	h_max = max(im1.shape[0], im2.shape[0]-offset_y)
	w_max = max(im1.shape[1], im2.shape[1]-offset_x)
	overlayedImg = np.zeros([h_max, w_max, 3], dtype=np.uint8)
	for h in range(h_max):
		for w in range(w_max):
			if image_nonzero_pixel(im2, h, w, offset_y, offset_x):
				overlayedImg[h, w] = im2[h+offset_y, w+offset_x]
			elif image_nonzero_pixel(im1, h, w):
				overlayedImg[h, w] = im1[h, w]
	return overlayedImg


def bilinear_interpol(image, w, h, sampled_w, sampled_h):
	pass

def warpImage(inputIm, refIm, H):
	# assuming images are np arrays [h, w, 3]
	# H is [3, 3]
	input_h, input_w, _ = inputIm.shape
	dim = max(input_h, input_w)
	# Iterate through all points in inputIm, calculate new location of points
	# in warpIm, set warpIm points to values in inputIm
	H_inv = np.linalg.inv(H)

	# Calculate bound offset with corners
	bounds = np.zeros([4, 2])
	bounds[0] = warp(H, 0, 0, 1)
	bounds[1] = warp(H, input_w-1, 0, 1)
	bounds[2] = warp(H, input_w-1, input_h-1, 1)
	bounds[3] = warp(H, 0, input_h-1, 1)

	min_x, max_x = np.min(bounds[:,0]), np.max(bounds[:,0])
	min_y, max_y = np.min(bounds[:,1]), np.max(bounds[:,1])
	warpIm = np.zeros([int(max_y - min_y)+1, int(max_x - min_x)+1, 3], dtype=np.uint8)
	warped_h, warped_w, _ = warpIm.shape
	for h in range(warped_h):
		for w in range(warped_w):
			w_map, h_map = warp(H_inv, w+min_x, h+min_y, 1)
			if w_map < input_w and w_map > 0 and h_map < input_h and h_map > 0:
				warpIm[h, w] = inputIm[int(h_map), int(w_map)]
	return warpIm, overlayImages(warpIm, refIm, int(min_y), int(min_x))


# Read images
# Format for terminal command: python Iyer_Ashwini_PS1.py pic1.jpg pic2.jpg cc1.npy cc2.npy
# If .npy files are not provided for corresponding points, then the user may
# choose the correspdonding points from the images

def main():
	if len(sys.argv) == 5:
		im1, im2, cc1, cc2 = sys.argv[1:5]
	elif len(sys.argv) == 3:
		im1, im2 = sys.argv[1:3]
		cc1, c22 = None, None
	else:
		print "Need to provide arguments for images and optional args for corresponding points"
		print "If you are providing a points file, please provide both points files separately"
		return
	imageOne = plt.imread(im1) # [319, 480, 3]
	imageTwo = plt.imread(im2) # [450, 317, 3]
	c1,c2 = np.array([1,2])
	# Read correspondences
	if cc1 == None or cc2 == None:
		fig1, ax1 = plt.subplots()
		cid = fig1.canvas.mpl_connect('button_press_event', onclick1)
		ax1.imshow(imageOne, aspect = 'equal')
		#ax1.set_xlim(0, imageOne.shape[0])
		#ax1.set_xlim(0, imageOne.shape[1])
		plt.show()
		fig1.canvas.mpl_disconnect(cid)
		print "printing pos1"
		print pos1


		fig2, ax2 = plt.subplots()
		cid = fig2.canvas.mpl_connect('button_press_event', onclick2)
		ax2.imshow(imageTwo)
		plt.show()
		fig2.canvas.mpl_disconnect(cid)
		print "printing pos2"
		print pos2
		c1 = np.array(pos1) # [12, 2]
		c2 = np.array(pos2) # [12, 2]
		points1 = c1
		points2 = c2
		# Save this to a .npy file
		np.save("points1".format(im1), points1) # [N, 2]
		np.save("points2".format(im2), points2) # [N, 2]

		# Saving points to an aggregate .npy file with dimensions [2, 2, N]
		c3 = np.array([np.swapaxes(c1, 0, 1), np.swapaxes(c2, 0, 1)])
		np.save("points", c3)
	else:
		c1 = np.load(cc1) # [12, 2] 
		c2 = np.load(cc2) # [12, 2]
	# Compute homography matrix
	""" Homography matrix notes:
		Takes in w, h -> w', h'
		To apply the homograph matrix, transforming from im1 -> img2
		given a corresponding point in img1, (x, y)
		x_new, y_new, _ = np.matmul(H, [x, y, 1]) """
	H = computeH(c1, c2)


	warpIm, mergeIm = warpImage(imageOne, imageTwo, H)

	# Show the images sequentially
	plt.imshow(imageOne)
	plt.show()
	plt.imshow(warpIm)
	plt.show()
	plt.imshow(mergeIm)
	plt.show()
	plt.imshow(imageTwo)
	plt.show()

if __name__ == '__main__':
	main()