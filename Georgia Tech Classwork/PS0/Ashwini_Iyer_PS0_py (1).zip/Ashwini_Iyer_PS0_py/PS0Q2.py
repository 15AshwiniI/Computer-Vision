import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from scipy import misc
from PIL import Image
import PIL.ImageOps

face = misc.face()
misc.imsave('inputPS0Q2.jpg',face)
misc.imsave('inputPS0Q2.png', face) # First we need to create the PNG file

face = misc.imread('inputPS0Q2.png')

type(face)      

face.shape, face.dtype

#switch red and green
f = face
f[:,:,[0, 1]] = f[:,:,[1, 0]]
misc.imsave('swapImgPS0Q2.png', f)

#image in greyscale
img = PIL.ImageOps.grayscale(Image.open('inputPS0Q2.png'))
img.save('grayImgPS0Q2.png')

#negative greyscale
inverted_image = PIL.ImageOps.invert(img)
inverted_image.save('negativeImgPS0Q2.png')

#mirror greyscale
mirror_image = PIL.ImageOps.mirror(img)
mirror_image.save('mirrorImgPS0Q2.png')

#average of mirror and greyscale
#need to find a new way to do this, apparently cant use blend function
avg=PIL.Image.blend(mirror_image,img,1.0/float(2))
avg.save("avgImgPS0Q2.png")

# Rename x and y
x = np.array(mirror_image).astype('uint32')
y = np.array(img).astype('uint32')
z = (x + y)/2
misc.imsave('avgImgPS0Q2.png', z)

#noise
gray_face = y 
N = np.random.randint(255, size=gray_face.shape).astype('uint32')
#import pdb; pdb.set_trace()
np.save('noise', N)

#Continue from here
noised_img = np.clip(N + y, 0, 255)
misc.imsave('addNoiseImgPS0Q2.png', noised_img)

#plots here
img1 = misc.imread('swapImgPS0Q2.png')
img2 = misc.imread('grayImgPS0Q2.png')
img3 = misc.imread('negativeImgPS0Q2.png')
img4 = misc.imread('mirrorImgPS0Q2.png')
img5 = misc.imread('avgImgPS0Q2.png')
img6 = misc.imread('addNoiseImgPS0Q2.png')

plt.figure()

plt.subplot(321)
plt.title('Red & Green Switched')
plt.xticks([])
plt.yticks([])
plt.imshow(img1)

plt.subplot(322)
plt.title('Grayscale')
plt.xticks([])
plt.yticks([])
plt.imshow(img2, cmap='gray')

plt.subplot(323)
plt.title('Negative Grayscale')
plt.xticks([])
plt.yticks([])
plt.imshow(img3, cmap='gray')

plt.subplot(324)
plt.title('Mirror Grayscale')
plt.xticks([])
plt.yticks([])
plt.imshow(img4, cmap='gray')

plt.subplot(325)
plt.title('Average of Grayscale & Mirror')
plt.xticks([])
plt.yticks([])
plt.imshow(img5, cmap='gray')

plt.subplot(326)
plt.title('Noise & Grayscale')
plt.xticks([])
plt.yticks([])
plt.imshow(img6, cmap='gray')

plt.show()

