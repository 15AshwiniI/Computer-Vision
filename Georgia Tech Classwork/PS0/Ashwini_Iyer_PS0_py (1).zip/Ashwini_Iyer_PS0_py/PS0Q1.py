import numpy as np 
import matplotlib.pyplot as plt


array = np.load('inputAPS0Q1.npy') #A
print array
reduced_array = array.reshape(-1)
array_descending = np.sort(reduced_array)[::-1]

#4a
plt.plot(array_descending)
plt.title('4a. A Sorted in Decreasing Order')
plt.ylabel('Intensity')
plt.show()

#4b
n, bins, patches = plt.hist(reduced_array, 20, normed=1, facecolor='g', alpha=0.75)
plt.xlabel('Value')
plt.ylabel('Probability')
plt.title('Histogram of A')
plt.grid(True)
plt.show()

#4c
#If 0 based indexing, 0-49 col and 50-99 row
X = array[50:99,0:49]
np.save('outputXPS0Q1.npy', X)
plt.imshow(X, interpolation=None)
plt.show()


#4d
mean = np.mean(array)
Y = array - mean
np.save('outputYPS0Q1.npy', Y)
plt.imshow(X, interpolation=None)
plt.show()

#4e
Z = np.zeros(shape=(100, 100, 3))
Z[array > mean] = [1, 0, 0]
plt.imshow(Z, interpolation=None)
plt.show()

