import numpy as np

a = np.random.randn(100, 100)
np.save('inputAPS0Q1', a)