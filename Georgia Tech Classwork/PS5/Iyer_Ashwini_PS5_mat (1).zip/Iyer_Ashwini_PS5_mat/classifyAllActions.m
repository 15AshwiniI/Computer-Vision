initialValueX = 480;
initialValueY = 640;
initialValueZ = 20;
allMHIs = zeros(initialValueX,initialValueY,initialValueZ);
initialHuX = 20;
initialHuY = 7;
huVectors = zeros(initialHuX,initialHuY);
actions_struct = {'botharms', 'crouch', 'leftarmup', 'punch', 'rightkick'};
numberActions = length(actions_struct);
actions_sub_struct = {'botharms-up', 'crouch', 'leftarm-up', 'punch', 'rightkick'};
starting_index = 1;
sequences_struct = {'-p1-1', '-p1-2', '-p2-1', '-p2-2'};
number_of_Sequences = length(sequences_struct);
counting_index = 1;

for i=starting_index:numberActions
    for j=starting_index:number_of_Sequences
        subdir = ['PS5_Data/', actions_struct{i}, '/', actions_sub_struct{i}, sequences_struct{j}, '/'];
        disp(['PS5_Data/', actions_struct{i}, '/', actions_sub_struct{i}, sequences_struct{j}, '/']);
        H = computeMHI(['PS5_Data/', actions_struct{i}, '/', actions_sub_struct{i}, sequences_struct{j}, '/']);
        allMHIs(:, :, counting_index) = computeMHI(['PS5_Data/', actions_struct{i}, '/', actions_sub_struct{i}, sequences_struct{j}, '/']);
        imagesc(computeMHI(['PS5_Data/', actions_struct{i}, '/', actions_sub_struct{i}, sequences_struct{j}, '/'])); 
        figure(counting_index); 
        title(['Action: ', actions_struct{i}, ' Seq: ', sequences_struct{j}]);
        saveas(counting_index, ['MHI-', actions_struct{i}, sequences_struct{j}, '.png'],'png');
        counting_index = counting_index+1;
    end
end

limit = numberActions*number_of_Sequences;
for i=starting_index:limit
    allMHI_split = allMHIs(:,:,i);
    hu_split = huVectors(i,:);
    huVectors(i,:) = huMoments(allMHI_split);    
end    

confusionMatrix = zeros(numberActions,numberActions);
for i=starting_index:limit
    [sequenceIdent, actionIdent] = ind2sub([number_of_Sequences, numberActions],i);
    huVectorsDup = huVectors;
    huVectorsDup(i,:) = [NaN,NaN,NaN,NaN,NaN,NaN,NaN];
    labelPredicted = predictAction(huVectors(i,:), huVectorsDup, [1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5]);
    confusionMatrix(actionIdent,labelPredicted) = confusionMatrix(actionIdent,labelPredicted)+1;
end
pretty(sym(confusionMatrix));