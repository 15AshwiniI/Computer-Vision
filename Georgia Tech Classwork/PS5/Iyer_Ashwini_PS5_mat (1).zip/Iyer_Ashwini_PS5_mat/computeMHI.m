function H = computeMHI(address)
    depthFilesDirectory = dir([address, '/*.pgm']);
    starting_index = 2;
    numberFrames = length(depthFilesDirectory);
    n_x = 480;
    n_y = 640;
    D = zeros(numberFrames, n_x, n_y, 'uint8');
    name = depthFilesDirectory(1).name; 
    previousFrame = imread([address, name]);
    n_D = 255;
    H = zeros(numberFrames, n_x, n_y, 'double');
    for i=starting_index:numberFrames  
        depth = imread([address, depthFilesDirectory(i).name]);
        index_val = double(depth)-double(previousFrame)>=10000;
        previousFrame = depth;
        H(i, ~index_val) = max(H(i-1, ~index_val)-1,0);
        D(i, index_val) = n_D;
        H(i, index_val) = numberFrames;
    end
    numerator = H(numberFrames,:);
    denominator = max(H(numberFrames,:));
    H = reshape(numerator/denominator, n_x,n_y);
end