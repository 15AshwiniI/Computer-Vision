actions_list = {'botharms', 'crouch', 'leftarmup', 'punch', 'rightkick'};
actions_sub = {'botharms-up', 'crouch', 'leftarm-up', 'punch', 'rightkick'};
initialValueX = 480;
initialValueY = 640;
initialValueZ = 20;
sequences_list = {'-p1-1', '-p1-2', '-p2-1', '-p2-2'};
struct_of_all_MHIs = zeros(initialValueX,initialValueY,initialValueZ);
initialHuX = 20;
initialHuY = 7;
huVectors_struct = zeros(initialHuX,initialHuY);
action_test_value=2;
counter = 1;
start_index = 1;
for i=start_index:length(actions_list)
    for j=start_index:length(sequences_list)
        H = computeMHI(['PS5_Data/', actions_list{i}, '/', actions_sub{i}, sequences_list{j}, '/']);
        f_id = length(findobj('type','figure'))+1;
        figure(f_id);
        struct_of_all_MHIs(:, :, counter) = H;
        imagesc(H);
        action_index = actions_list{i};
        seq_index = sequences_list{j};
        title(['Action: ', action_index, ' Seq: ', seq_index]);
        f_id = length(findobj('type','figure'))+1;
        saveas(f_id-1, ['MHI-', action_index, seq_index, '.png'],'png');
        counter = counter+1;
    end
end

actionsLength = length(actions_list);
seqLength = length(sequences_list);
endIndex = actionsLength*seqLength;
for i=start_index:endIndex
    huVectors_struct(i,:) = huMoments(struct_of_all_MHIs(:,:,i));    
end  

label_predicted = predictAction(huVectors_struct(action_test_value,:), huVectors_struct, [1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5]);

[sequenceIdent, actionIdent] = ind2sub([length(sequences_list), length(actions_list)],action_test_value);
f_id = length(findobj('type','figure'))+1;
figure(f_id);
subplot(3,2,1);
imagesc(struct_of_all_MHIs(:,:,action_test_value));
title(['Test HMI (Action: ', actions_list{actionIdent}, ' Seq: ',num2str(sequenceIdent),')']);
for i=start_index:4
    [sequenceIdent, actionIdent] = ind2sub([length(sequences_list), length(actions_list)],label(i));
    subplot_x = 3;
    subplot_y = 2;
    subplot_z = i+1;
    subplot(subplot_x,subplot_y,subplot_z);
    imagesc(struct_of_all_MHIs(:,:,label(i)));
    action_value_temp = actions_list{actionIdent};
    seq_value_temp = sequences_list{sequenceIdent};
    i_temp = num2str(i);
    title(['Nearest neighbor (K:',i_temp, ') Action: ', seq_value_temp, ' Seq: ', num2str(sequenceIdent)]);
end
action_value_final = actions_list{actionIdent};
seq_value_final = sequences_list{sequenceIdent};
f_id = length(findobj('type','figure'))+1;
%saveas(f_id-1, ['matched-', num2str(action_test_value), '-', num2str(label(i)), action_value_final, seq_value_final,'-k-',num2str(i-1), '.png'],'png');

%save('allMHIs.mat', 'allMHIs');
%save('huVectors.mat', 'huVectors');