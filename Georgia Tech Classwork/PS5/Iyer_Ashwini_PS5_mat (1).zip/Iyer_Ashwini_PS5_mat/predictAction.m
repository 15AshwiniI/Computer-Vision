function predictedLabel = predictAction(testingMoments, trainingMoments, trainingLabels)
    starting_index = 1;
    ending_index = 4;
    variance_value = nanvar(trainingMoments);
    [height,~] = size(trainingMoments);
    distances_struct = zeros(height,starting_index);
    for i=starting_index:height
        difference = trainingMoments(i,:)-testingMoments;
        diff_sqred = difference.^2;
        diff_div = diff_sqred./variance_value;
        distances_struct(i) = sqrt(sum(diff_div));
    end
    [X, Y] = sort(distances_struct);
    predictedLabel = mode(trainingLabels(Y(starting_index:ending_index)));
    assignin('base','label', Y);
end