%clc; close all; clear all;
siftdirectory = 'sift';
numClusters = 300;
frame_names = dir([siftdirectory '/*.mat']);
framesdirectory = 'frames';
frameOfInterest = [130:135];
N_specific = 100; 
numberOfFrames = 500;
numberOfCandidate = 10;
featureSpace.featureMap = [];
for i=1:numberOfFrames
    fname_toLoad = [siftdirectory, '/friends_0000000', num2str(N_specific+i), '.jpeg.mat'];
    load(fname_toLoad, 'imname', 'descriptors', 'positions', 'scales', 'orients');
    imname = [framesdirectory '/' imname]; 
    im = imread(imname);
    [height,width,~]  =  size(im);
    nFeatures = min([N_specific,size(descriptors,1)]);
    featureSpace.featureMap = [featureSpace.featureMap; descriptors];
    featureSpace.feature(i).nFeatures = size(descriptors,1);
    featureSpace.feature(i).imname = cellstr(imname);
    featureSpace.feature(i).positions = positions;
    featureSpace.feature(i).orientations = orients;
    featureSpace.feature(i).features = descriptors;
    featureSpace.feature(i).scales = scales;
    clear scales im descriptors orients positions
end
[membership,means,rms] = kmeansML(numClusters,featureSpace.featureMap');
frameHistogram = zeros(numberOfFrames,numClusters);
membershipDup = membership;
cellNo = 1;
memberShip = cell(cellNo,numberOfFrames);
for i=1:numberOfFrames
    cutNo = 1;
    featureFeatures = featureSpace.feature(i).nFeatures;
    memberShip{i} = membership(cutNo:featureFeatures);
    membershipDup(cutNo:featureFeatures) = [];
    for j=1:numClusters
        frameHistogram(i, j) = frameHistogram(i, j) + sum(sort(membership(cutNo:featureFeatures)) == j);
    end
end
listOfWords = zeros(1,numClusters);
for frame=132:132+length(frameOfInterest)-1
    figure;
    fframe = featureSpace.feature(frame);
    im = imread(char(fframe.imname));
    fframe.imname
    featureFeatures = fframe.nFeatures;
    f_pos = fframe.positions(1:featureFeatures,:);
    oninds = selectRegion(im, f_pos);
    for j=1:numClusters
        mem = membership(oninds);
        listOfWords(j) = listOfWords(j) + sum(mem == j);
    end
    featurePositions = fframe.positions(oninds,:);
    featureScales = fframe.scales(oninds);
    featureFeatures1 = fframe.orientations(oninds);
    displaySIFTPatches(featurePositions, featureScales, featureFeatures1, im); 
end
startPlace = 1; 
normalMat = zeros(numberOfFrames,startPlace);
current_score = zeros(startPlace,numberOfFrames);
for i=1:numberOfFrames
    normalMat(i) = norm(frameHistogram(i,:));
end
wordProd = listOfWords*frameHistogram';
normProd = norm(listOfWords)*normalMat';
current_score = wordProd./normProd;
A = isnan(current_score);
current_score(A) = 0;
[value, id] = sort(current_score, 'descend'); 
firstIndex = 1;
value(firstIndex:numberOfCandidate)
id(firstIndex:numberOfCandidate)
figure;
for candidate=firstIndex:numberOfCandidate
    candidateID = id(candidate);
    candidateName = featureSpace.feature(candidateID).imname;
    imageCandidate = imread(char(candidateName));
    subplot(1,numberOfCandidate,candidate); 
    imshow(imageCandidate);
end