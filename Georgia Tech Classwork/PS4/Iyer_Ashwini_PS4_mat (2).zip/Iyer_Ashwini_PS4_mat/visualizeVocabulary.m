% clc; close all; clear all;
constA = 25;
constB = 300;
dirName = 'vocabulary';
subdirName = 'vocabulary/W';
frameCount = 500;
%uniqMem = cell(1, frameCount);
siftVar = 'sift';
mkdir(dirName);
dirOfFrames = 'frames';
kClusters = constB;
resultHist = zeros(frameCount, kClusters);
featureSpace = createFeatureSpace(dirOfFrames, siftVar, frameCount);
patchesNum = constA;
fprintf('Clustering');
[memShip, means, rms] = kmeansML(kClusters, featureSpace.features');
memshipDup = memShip;
memShip = cell(1,frameCount);
for i = 1 : frameCount
    %totalFrames = featureW.frameId(i);
    memShip{i} = memshipDup(1 : featureSpace.frameID(i));
    myId = sort(memshipDup(1: featureSpace.frameID(i)));
    memshipDup(1 : featureSpace.frameID(i)) = [];
    for k = 1 : kClusters
        numPointsInCluster = sum(myId == k);
        temp = numPointsInCluster + resultHist(i, k);
        resultHist(i, k) = temp;
    end
    clear myId
end
clear membershipDup
fprintf('Outputting to File');
for clust = 1 : kClusters
    strClust = num2str(clust);
    mkdir([subdirName, strClust]);
    myVar = find(resultHist(:, clust) > 0);
    lenX = length(myVar);
    randomFrames = myVar(randperm(lenX));
    numRandomFrames = length(randomFrames);
    minNumFrames = min(patchesNum, numRandomFrames);
    randomFrames = randomFrames(1 : minNumFrames);
    clear myVar;
    for k = 1 : minNumFrames
        strK = num2str(k);
        myVar = find(memShip{randomFrames(k)} == clust)
        patch_descr = ' patches from '
        str_descr = ' word matches in the image)';
        str = [strK, patch_descr,  num2str(myVar'), ' image (', strClust, str_descr ]
        ext = '.png';
        temp3 = featureSpace.frameCumulative(randomFrames(k))
        myId = myVar + temp3;
        
        name = featureSpace.imname{randomFrames(k)};
        charName = char(name);
        im = rgb2gray(imread(charName));
        featurePos = featureSpace.positions(myId(1),:);
        featureOr = featureSpace.orientations(myId(1));
        featureScale = featureSpace.scales(myId(1));
        myPatch = getPatchFromSIFTParameters(featurePos, featureScale, featureOr, im);
        imwrite(myPatch,[subdirName, strClust, '/P', strK, ext]);
    end
end