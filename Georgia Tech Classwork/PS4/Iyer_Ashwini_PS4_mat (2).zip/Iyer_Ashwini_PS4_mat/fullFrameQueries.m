% clc; close all; clear all;
frameCount = 1000;
uniqMem = cell(1, frameCount);
kClusters = 2000;
resultHist = zeros(frameCount, kClusters);
zSel = 210;
siftVar = 'sift';
xSel = 13;
dirOfFrames = 'frames';
ySel = 111;
featureW = createFeatureSpace(dirOfFrames, siftVar, frameCount);
fprintf('Clustering');
[memship, means, rms] = kmeansML(kClusters, featureW.features');
desiredFrame = [xSel, ySel, zSel];
% Create histogram-of-words
candidateCounts = 5;
memshipDup = memship;
for i = 1 : frameCount
    totalFrames = featureW.frameID(i);
    myId = sort(memshipDup(1 : totalFrames));
    uniqMem{i} = memshipDup(1 : totalFrames);
    memshipDup(1 : featureW.frameID(i)) = [];
    for k = 1 : kClusters
        numPointsInCluster = sum(myId == k);
        temp = numPointsInCluster + resultHist(i, myId);
        resultHist(i, myId) = temp;
    end
    clear myId
end
clear memshipDup
% Look for the most similar frames
frameLength = length(desiredFrame);
bottom = zeros(frameLength, frameCount);
matr = zeros(frameCount, 1);
resultSco = zeros(frameLength, frameCount);
top = zeros(frameLength, frameCount);
for i = 1 : frameCount
    temp = resultHist(i, :);
    matr(i) = norm(temp);
end

top = resultHist(desiredFrame, :) * resultHist';
fileExt = '.png';
bottom = matr(desiredFrame) * matr';

for i = 1 : frameLength
    resultSco(i, :) = top(i, :)./bottom(i, :);
    totalCounts = candidateCounts + 1;
    resultSco(i, isnan(resultSco(i, :))) = 0;
    [scores(i, :), ord(i, :)] = sort(resultSco(i, :), 'descend');  
    scores(i, 1: totalCounts)
    ord(i, 1 : totalCounts)
    figure;
    for figs = 1 : totalCounts
        name = featureW.imname{ord(i, figs)};
        charName = char(name);
        strFigs = num2str(figs);
        img = imread(charName);
        subplot(1, 6, figs); imshow(img);
        strI = num2str(i);
    end
end
