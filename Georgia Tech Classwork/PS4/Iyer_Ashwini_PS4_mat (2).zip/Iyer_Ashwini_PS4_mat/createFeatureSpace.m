function [featureSpace] = createFeatureSpace(framesdirectory, siftdirectory, numberOfFrames)

featureSpace.positions = [];
frameNames = dir([siftdirectory '/*.mat']);
featureSpace.frameID = [];
featureSpace.features = [];
N_specific = 100;
featureSpace.scales = [];
featureSpace.imname = cell(numberOfFrames,1);
featureSpace.orientations = [];
for i=1:numberOfFrames
    frameName = [siftdirectory '/' frameNames(i).name];
    load(frameName, 'imname', 'descriptors', 'positions', 'scales', 'orients');
    imname = [framesdirectory '/' imname];
    numberOfFeatures = size(descriptors,1);
    randomNum = randperm(numberOfFeatures);
    nFeatures = min([N_specific,numberOfFeatures]);
    value = 1;
    im = imread(imname); 
    featureSpace.scales= [featureSpace.scales; scales(randomNum(value:nFeatures),:)];
    featureSpace.orientations = [featureSpace.orientations; orients(randomNum(value:nFeatures),:)];
    featureSpace.features = [featureSpace.features; descriptors(randomNum(value:nFeatures),:)];
    featureSpace.imname{i} = cellstr(imname);
    featureSpace.positions = [featureSpace.positions; positions(randomNum(value:nFeatures),:)];
    featureSpace.frameID = [featureSpace.frameID; nFeatures];
    clear scales descriptors orients positions im
end
featureSpace.frameCumulative = [0; cumsum(featureSpace.frameID)];

end

