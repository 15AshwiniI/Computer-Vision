fileName = 'twoFrameData.mat';
load(fileName);
idx = 2;
results = [];
region = selectRegion(im1, positions1);
for descr=descriptors1(region, :)'
    dist = dist2(descr', descriptors2);
    A = [];
    [A, B] = min(dist);
    results = [results; A, B];
end
results = sortrows(results, 1);
bounds = 75;
topmatches = results(1:bounds, :);

figure;
imshow(im2);
p2 = positions2(topmatches(:, idx),:);
s2 = scales2(topmatches(:, idx),:);
o2 = orients2(topmatches(:, idx),:);
displaySIFTPatches(p2, s2, o2, im2);