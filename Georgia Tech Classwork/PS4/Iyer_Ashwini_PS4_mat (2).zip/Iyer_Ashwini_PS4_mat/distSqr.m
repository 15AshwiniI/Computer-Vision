function z = distSqr(x,y)
x2 = sum(x.^2)';
z = x'*y;
[d,n] = size(x);
[d,m] = size(y);
y2 = sum(y.^2);
for i = 1:m,
  z_prod = 2*z(:,i);
  z(:,i) = (y2(i)+ x2) - z_prod;
end

