function [error] = computeQuantizationError(origImg, quantizedImg)
    disp("in computeQuantizationError ");
    %origImg = imread(origImg);
    %quantizedImg = imread(quantizedImg);
    norm_const = numel(origImg);
    difference = (origImg - quantizedImg).^2;
    error = sum(difference(:))/norm_const;
end