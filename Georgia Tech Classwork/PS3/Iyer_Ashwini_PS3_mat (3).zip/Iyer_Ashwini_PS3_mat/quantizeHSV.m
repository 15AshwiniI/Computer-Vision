function [outputImg, meanColors] = quantizeHSV(origImg, k)
    %inputImage = imread(inputImage);
    [h, w, ~] = size(origImg);
    outputImg = origImg;
    new_dim = h*w;
    [outputs, meanColors] = kmeans(double(reshape(origImg(:, :, 1), new_dim, 1)), ...
        k, 'MaxIter', 225, 'EmptyAction', 'drop');
    outputs = reshape(outputs, h, w);
    for i=1:w
        for j=1:h
            temp = meanColors(outputs(j, i));
            % Need to use uint8 type
            outputImg(j, i, 1) = uint8(temp);
        end
    end
    %imshow(outputImage);
end