k = 10;
strK = num2str(k);
inputImg.RGB = imread('fish.jpg');
% Printing histogram stuff afterwards
% Part D
[histEqual, histClustered] = getHueHists(inputImg.RGB, k);
figure(4);  hold on; grid MINOR; title('Hue Histograms');
lineWidth = 4;
maxStem = 255;
stem(0:maxStem, histEqual, 'r', 'LineWidth', lineWidth);
stem(0:maxStem, histClustered, 'g', 'LineWidth', lineWidth); 
legend(['Equally-spaced Hist k= ', strK], ['Clustered Center Memberships k= ', num2str(k)], 'Location', 'northeast');

% Input Img
figure(1);
%inputImg.RGB = imread('fish.jpg');
[outputImage.RGB, meanColors] = quantizeRGB(inputImg.RGB, k);
subplot(3, 1, 1);
imshow(inputImg.RGB); 
title('Input Image');
inputImg.HSV = rgb2hsv(inputImg.RGB);
inputImg.HSVuint = uint8(255 * inputImg.HSV);
subplot(3, 1, 2); 
imshow(outputImage.RGB); 
title(['RGB Qz. Image (k= ', strK, ')']);
[outputImage.HSV, ~] = quantizeHSV(inputImg.HSVuint, k);
temp = double(outputImage.HSV)/255.0;
subplot(3, 1, 3); 
imshow(hsv2rgb(temp)); 
title(['HSV Qz. Img (k= ', strK, ')']);
% No suppression of I/O output here to print
% quantization error from the compute functions
error.RGB = computeQuantizationError(inputImg.RGB,outputImage.RGB)
error.HSV = computeQuantizationError(inputImg.HSVuint, outputImage.HSV)