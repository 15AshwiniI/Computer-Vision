
function [outputImg, meanColors] = quantizeRGB(origImg, k)
    %inputImage = imread(inputImage);
    [h, w, c] = size(origImg);
    collapsed_dim = h * w;
    outputImg = zeros(h, w, c, 'uint8');
    [outputs, meanColors] = kmeans(double(reshape(origImg, collapsed_dim, c)), ...
        k, 'MaxIter', 225);
    outputs = reshape(outputs, h, w);
    for i=1:w
        for j=1:h
            outputImg(j, i, :) = meanColors(outputs(j, i),:);
        end
    end
    %imwrite(outputImg, 'RGBquantized.jpg');
    %imshow(outputImage);
end