function [histEqual, histClustered] = getHueHists(im, k)
    HSV.double = rgb2hsv(im);
    HSV.uint8 = uint8(255 * HSV.double);
    % This is how to interact with the HSV map
    [quantOutput, ~] = quantizeHSV(HSV.uint8, k);
    [histCounts, idx] = imhist(HSV.uint8(:, :, 1), k);
    true_idx = round(idx + 1);
    histEqual = zeros(1, 255);
    histEqual(true_idx) = histCounts;
    [histClustered, ~] = imhist(quantOutput(:, :, 1));
end