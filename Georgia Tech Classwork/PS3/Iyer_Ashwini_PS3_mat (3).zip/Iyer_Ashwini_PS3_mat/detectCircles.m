function [centers] = detectCircles(im, radius, useGradient)
%     im = rgb2gray(imread(im));
    im = rgb2gray(im);
    [~, gradDir] = imgradient(im);
    [h, w, ~] = size(im);
    centers.edges = edge(im, 'canny', 0.8, 6);
    centers.houghSpace = zeros(h, w);
    gradDir = pi + 0.0175 * gradDir;
    [desiredIndicesX, desiredIndicesY] = find(1 == centers.edges);
    desiredAngle = 0:0.01:2*pi;
    centers.centers = zeros(h, w, 1);
    centers.votes = zeros(h, w);
    for counter=1:prod(size(desiredIndicesX))
        center.y = desiredIndicesX(counter);
        center.x = desiredIndicesY(counter);
        if(useGradient ~= 1)
            new_angle = desiredAngle; 
        else
            new_angle = gradDir(center.y, center.x);
            new_angle = [new_angle; new_angle - pi];
        end
        a = radius * cos(new_angle) + center.x;
        b = radius * sin(new_angle) + center.y;
        % Setting new a and b, and based on condition setting to empty
        % lists
        a(a>w) = [];
        a(a<1) = [];
        b(b>h) = [];
        b(b<1) = [];
        bIdx = round(b);
        aIdx = round(a);
        centers.houghSpace(bIdx, aIdx) = centers.houghSpace(bIdx, aIdx) + 1;
    end
	centersList = centers.houghSpace;
    meanVote = mean(centers.votes(:));
    % Quick way to remove votes less than mean
    centers.votes(centers.votes < meanVote) = [];
    [centers.votes, new_ord] = sort(centersList(:), 'descend');    
    rangeConst = 20;
    centers.centers = reshape(new_ord, h, w);       
    
    [idxI,idxJ] = ind2sub(size(centers.centers), centers.centers);
    centers.coordinates = [idxJ(1:rangeConst)', idxI(1:rangeConst)'];    
end