% comment the bottom line and uncomment the line after for mall pics
im = imread('inputSeamCarvingPrague.jpg');
% im = imread('inputSeamCarvingMall.jpg');
energyImage = energy_image(im);
reducedColorImage = im;
reducedEnergyImage = energyImage;
for it = 1:100
    [reducedColorImage, reducedEnergyImage] = reduceHeight(reducedColorImage, reducedEnergyImage);
end

% Write out images
% comment the bottom line and uncomment the line after for mall pics
imwrite(reducedColorImage, 'outputReduceHeightPrague.png');
% imwrite(reducedColorImage, 'outputReduceHeightMall.png');
figure()
%imshow(reducedColorImage);
imagesc(reducedColorImage);