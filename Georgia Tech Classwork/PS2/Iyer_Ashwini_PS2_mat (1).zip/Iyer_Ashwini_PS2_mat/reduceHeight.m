function [reducedColorImage, reducedEnergyImage] = reduceHeight(im, energyImage)
    [h, w, c] = size(im);
    % Reducing height by 1
    newHeight = h-1;
    reducedColorImage = zeros(newHeight, w, c, 'uint8');
%     newEnergyMap = zeros(newHeight, w);
    cumulativeEnergyMap = cumulative_minimum_energy_map(energyImage, 'HORIZONTAL');
    optimalHorizontalSeam = find_optimal_horizontal_seam(cumulativeEnergyMap);
%     figure(2);
%     imagesc(cumulativeEnergyMap);
%     displaySeam(image, optimalHorizontalSeam, 'HORIZONTAL');
    for x = 1:w
        remCol = optimalHorizontalSeam(x);
        for color = 1:3
            temp = im(:, x, color);
            temp(remCol) = [];
            reducedColorImage(:, x, color) = temp;
        end
    end
    reducedEnergyImage = energy_image(reducedColorImage);

end