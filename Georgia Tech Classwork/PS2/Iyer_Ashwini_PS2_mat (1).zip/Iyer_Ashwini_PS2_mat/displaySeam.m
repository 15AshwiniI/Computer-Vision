function displaySeam(im, seam, type)
    [h, w, ~] = size(im);
    figure(1);
    imshow(im);
    hold on;
    if(strcmp(type, 'HORIZONTAL'))
        plot(1:w, seam, 'g*');
    elseif(strcmp(type, 'VERTICAL'))
        plot(seam, 1:h, 'r*');
    end
    hold off;

end