function [ energyImage ] = energy_image (im)

    G = im2double(rgb2gray(im));

    % Sobel filters described in lecture
    y_filter = [1 2 1; 0 0 0; -1 -2 -1];
    x_filter = [1 0 -1; 2 0 -2; 1 0 -1];
    
%     % Prewitt filters
%     y_filter = [1 1 1; 0 0 0; -1 -1 -1];
%     x_filter = [-1 0 1; -1 0 1; -1 0 1];
    
%     % Gaussian filter
%     y_filter = [1 2 1; 2 4 2; 1 2 1];
%     x_filter = [1 2 1; 2 4 2; 1 2 1];

    grad_y = imfilter(G, y_filter);
    grad_x = imfilter(G, x_filter);

    [h, w, ~] = size(im);
    % Initialize return val
    energyImage = zeros(h, w);
    for y = 1:h
        for x = 1:w
            energyImage(y, x) = sqrt(grad_y(y, x)^2 + grad_x(y, x)^2);
        end
    end

end