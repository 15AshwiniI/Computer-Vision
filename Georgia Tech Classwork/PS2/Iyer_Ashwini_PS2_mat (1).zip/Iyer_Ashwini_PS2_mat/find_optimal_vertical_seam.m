function [ verticalSeam ] = find_optimal_vertical_seam(cumulativeEnergyMap)
    [h, w, ~] = size(cumulativeEnergyMap);
    [~, temp] = min(cumulativeEnergyMap(h, :));
    verticalSeam = zeros(h, 1);
    verticalSeam(h) = temp;
    for row = h-1:-1:1
        currSeam = verticalSeam(row + 1);
        boundLower = max(1, currSeam - 1);
        offset = boundLower - 1;
        boundHigher = min(w, currSeam + 1);
        [~, newIndex] = min(cumulativeEnergyMap(row, boundLower:boundHigher));
        verticalSeam(row) = offset + newIndex;
    end
end