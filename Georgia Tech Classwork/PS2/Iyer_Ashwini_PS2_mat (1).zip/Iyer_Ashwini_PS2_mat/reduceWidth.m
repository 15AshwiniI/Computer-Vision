function [reducedColorImage, reducedEnergyImage] = reduceWidth(im, energyImage)
    [h, w, c] = size(im);
    % Reducing height by 1
    newWidth = w-1;
    reducedColorImage = zeros(h, newWidth, c, 'uint8');
%     newEnergyMap = zeros(h, newWidth);
    cumulativeEnergyMap = cumulative_minimum_energy_map(energyImage, 'VERTICAL');
    optimalVerticalSeam = find_optimal_vertical_seam(cumulativeEnergyMap);
%     figure(2);
%     imagesc(cumulativeEnergyMap);
%     displaySeam(image, optimalVerticalSeam, 'VERTICAL');
    for y = 1:h
        remRow = optimalVerticalSeam(y);
        for color = 1:3
            temp = im(y, :, color);
            temp(remRow) = [];
            reducedColorImage(y, :, color) = temp;
        end
    end
    reducedEnergyImage = energy_image(reducedColorImage);

end