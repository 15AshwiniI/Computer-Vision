function [ horizontalSeam ] = find_optimal_horizontal_seam(cumulativeEnergyMap)
    [h, w, ~] = size(cumulativeEnergyMap);
    [~, temp] = min(cumulativeEnergyMap(:, w));
    horizontalSeam = zeros(w, 1);
    horizontalSeam(w) = temp;
    for x = w-1:-1:1
        currSeam = horizontalSeam(x + 1);
        boundLower = max(1, currSeam - 1);
        offset = boundLower - 1;
        boundHigher = min(h, currSeam + 1);
        [~, newIndex] = min(cumulativeEnergyMap(boundLower:boundHigher, x));
        horizontalSeam(x) = offset + newIndex;
    end
end
    