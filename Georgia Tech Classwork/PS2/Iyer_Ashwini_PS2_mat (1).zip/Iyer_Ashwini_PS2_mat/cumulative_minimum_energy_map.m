function [cumulativeEnergyMap] = cumulative_energy_map(energyImage, seamDirection)
    
    [h, w, ~] = size(energyImage);
    cumulativeEnergyMap = zeros(h, w);
    
    if (strcmp('HORIZONTAL', seamDirection))
        for col=2:w
            for row=1:h
                bounded_y_min = max(1, row-1);
                bounded_y_max = min(h, row+1);
                % Basically, compute the min over the corresponding range
                minVal = min(cumulativeEnergyMap(bounded_y_min:bounded_y_max, col-1));
                cumulativeEnergyMap(row, col) = minVal + energyImage(row, col);
            end
        end
    elseif (strcmp('VERTICAL', seamDirection))
        for row=2:h
            for col=1:w
                bounded_x_min = max(1, col-1);
                bounded_x_max = min(w, col+1);
                minVal = min(cumulativeEnergyMap(row-1, bounded_x_min:bounded_x_max));
                cumulativeEnergyMap(row, col) = minVal + energyImage(row, col);
            end
        end
    end

end